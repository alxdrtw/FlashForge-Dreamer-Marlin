import configparser,hashlib,json,tempfile,threading,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import bootloader,suite

class Device:
    idVendor=0x0315;idProduct=1
    def __init__(self,short=False):self.parts=[];self.short=short
    def write(self,endpoint,data,timeout):
        assert endpoint==3
        self.parts.append(data);return len(data)-int(self.short)

class FakePrinter:
    commands=[];bad_checksum=False;control_failures=0
    def __init__(self,**kwargs):pass
    def command(self,command,timeout=0):
        self.commands.append(command)
        if command.startswith('M601'):
            if self.control_failures:type(self).control_failures-=1;raise RuntimeError('No control yet')
            return 'Control Success.\nok\n'
        if command.startswith('M28'):return 'Writing to file: dreamer.bin\nok\n'
        if command.startswith('M29'):return 'Failed\nok\n' if self.bad_checksum else 'Done saving file.\nok\n'
        if command=='M600':return 'succeed\nok\n'
        return 'ok\n'

class BootloaderTests(unittest.TestCase):
    def setUp(self):FakePrinter.commands=[];FakePrinter.bad_checksum=False;FakePrinter.control_failures=0
    def run_transfer(self,device=None,**kwargs):
        device=device or Device();responses=iter([[],[device]])
        with patch.object(bootloader,'Printer',FakePrinter),patch.object(bootloader.usb.util,'claim_interface'),patch.object(bootloader.usb.util,'dispose_resources'):
            result=bootloader.install(b'test firmware'*2000,log=lambda _:None,scan=lambda:next(responses,[device]),sleep=lambda _:None,**kwargs)
        return result,device
    def test_bootloader_without_length_echo(self):
        ok,device=self.run_transfer();self.assertTrue(ok)
        self.assertEqual(b''.join(device.parts),b'test firmware'*2000)
        self.assertIn('M29 '+hashlib.md5(b'test firmware'*2000).hexdigest(),FakePrinter.commands)
        self.assertLess(FakePrinter.commands.index(next(c for c in FakePrinter.commands if c.startswith('M29'))),FakePrinter.commands.index('M600'))
    def test_checksum_failure_never_arms(self):
        FakePrinter.bad_checksum=True
        with self.assertRaisesRegex(RuntimeError,'сумма'):self.run_transfer()
        self.assertNotIn('M600',FakePrinter.commands)
    def test_short_transfer_never_arms(self):
        with self.assertRaisesRegex(RuntimeError,'Неполная'):self.run_transfer(Device(short=True))
        self.assertNotIn('M600',FakePrinter.commands)
    def test_cancel_before_write(self):
        cancel=threading.Event();cancel.set()
        with self.assertRaisesRegex(RuntimeError,'отменено'):self.run_transfer(cancel=cancel)
        self.assertEqual(FakePrinter.commands,[])
    def test_retry_control(self):
        FakePrinter.control_failures=7
        self.assertTrue(self.run_transfer()[0]);self.assertEqual(FakePrinter.commands.count('M601 S0'),8)
    def test_multiple_devices_rejected(self):
        responses=iter([[],[Device(),Device()]])
        with self.assertRaisesRegex(RuntimeError,'несколько'):
            bootloader.install(b'x',scan=lambda:next(responses),log=lambda _:None)
        self.assertEqual(FakePrinter.commands,[])

class SuiteTests(unittest.TestCase):
    def test_bundled_marlin_is_hardware_verified_image(self):
        suite.verify()
        self.assertEqual(hashlib.sha256(suite.checked('marlin.bin')).hexdigest(),'b25d2a4a3a41e2d63992d1713bafa41b3625393495065dffbaf4a98d5ea9eef8')
    def test_export_includes_profiles_and_manual(self):
        with tempfile.TemporaryDirectory() as folder:
            exported=suite.export_bundle(folder)
            for name in ('Инструкция.html','Profiles/Dreamer-ABS-LEFT-Tuned.curaprofile','Profiles/FlashPrint-Standard-Dreamer.curaprofile','DREAMER_MARLIN_CURA_WIFI.bin','Sources/Marlin-Cura-WiFi-sources.zip'):
                self.assertTrue((exported/name).is_file(),name)
            self.assertFalse((exported/'Cura-install/cura.cfg').exists())
    def test_cura_install_preserves_other_printer_and_account_preferences(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder);prefs=config/'cura.cfg'
            prefs.write_text('[account]\nprivate_test_value = preserve-me\n[cura]\nactive_machine = other\n[um3networkprinting]\nmanual_instances = other-host\n',encoding='utf-8')
            other=config/'definitions/other.def.json';other.parent.mkdir();other.write_text('other printer')
            reply=suite.install_cura(config,check_running=False)
            c=configparser.ConfigParser();c.read(prefs,encoding='utf-8')
            self.assertEqual(c['account']['private_test_value'],'preserve-me')
            self.assertIn('other-host',c['um3networkprinting']['manual_instances'])
            self.assertEqual(c['cura']['active_machine'],suite.STACK)
            self.assertEqual(other.read_text(),'other printer')
            self.assertTrue(list((config/'backups').glob('*/cura.cfg')))
            for t,enabled in ((0,'False'),(1,'True')):
                c.read(config/f'extruders/{suite.STACK}_T{t}.extruder.cfg',encoding='utf-8')
                self.assertEqual(c['metadata']['enabled'],enabled)
    def test_running_cura_blocks_profile_mutation(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(suite,'cura_running',return_value=True):
            with self.assertRaisesRegex(RuntimeError,'Закрой Cura'):suite.install_cura(folder)
            self.assertEqual(list(Path(folder).iterdir()),[])
    def test_invalid_ip(self):
        for value in ('192.168.88.222:8899','a; command','999.1.1.1',''):
            with self.assertRaises(ValueError):suite.validate_ip(value)
    def test_frozen_relay_has_independent_runtime(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(suite,'DATA',Path(folder)),patch.object(suite.sys,'frozen',True,create=True),patch.object(suite.socket,'socket') as socket,patch.object(suite.subprocess,'Popen') as process:
            socket.return_value.__enter__.return_value.connect_ex.return_value=1
            process.return_value.pid=99
            suite.start_relay('192.168.88.222')
            self.assertEqual(process.call_args.kwargs['env']['PYINSTALLER_RESET_ENVIRONMENT'],'1')
            self.assertIn('--wifi-relay',process.call_args.args[0])
    def test_no_credentials_in_portable_profile_bundle(self):
        with zipfile.ZipFile(suite.ASSETS/'bundle.zip') as z:
            self.assertFalse(any(Path(n).name=='cura.cfg' for n in z.namelist()))
            for n in z.namelist():
                if n.startswith('Cura-install/'):
                    text=z.read(n).decode('utf-8').lower()
                    for forbidden in ('access_token','refresh_token','password ='):
                        self.assertNotIn(forbidden,text)

if __name__=='__main__':unittest.main()
