import http.client, json, threading, time, unittest, zlib
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from dreamer_cura_bridge import serve

class Upstream(BaseHTTPRequestHandler):
 active=0; maximum=0; uploaded=[]; compatible=True; crc=''
 receiving=threading.Event()
 def log_message(self,*args): pass
 def do_GET(self):
  type(self).active+=1; type(self).maximum=max(self.maximum,self.active)
  time.sleep(.015)
  data=json.dumps({'platform':'Marlin / Cura local API' if self.compatible else 'raw'}).encode()
  self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  type(self).active-=1
 def do_POST(self):
  self.receiving.set()
  data=self.rfile.read(int(self.headers['Content-Length']));self.uploaded.append(data)
  type(self).crc=self.headers.get('X-Dreamer-CRC32')
  self.send_response(201);self.send_header('Content-Length','2');self.end_headers();self.wfile.write(b'{}')

class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.up=ThreadingHTTPServer(('127.0.0.1',0),Upstream)
  threading.Thread(target=cls.up.serve_forever,daemon=True).start()
  threading.Thread(target=serve,args=('127.0.0.1',cls.up.server_port,18897),daemon=True).start()
  time.sleep(.1)
 def request(self,method,path,body=None):
  c=http.client.HTTPConnection('127.0.0.1',18897,timeout=5)
  try:
   c.request(method,path,body=body);r=c.getresponse();return r.status,r.read()
  finally:c.close()
 def test_parallel_requests_serialized(self):
  with ThreadPoolExecutor(max_workers=6) as pool:
   replies=list(pool.map(lambda _:self.request('GET','/api/v1/system'),range(12)))
  self.assertTrue(all(r[0]==200 for r in replies));self.assertEqual(Upstream.maximum,1)
 def test_upload_exact_bytes(self):
  payload=b'G21\n; harmless diagnostic fixture\n'*100
  self.assertEqual(self.request('POST','/cluster-api/v1/print_jobs/',payload)[0],201)
  self.assertEqual(Upstream.uploaded[-1],payload)
  self.assertEqual(Upstream.crc,f'{zlib.crc32(payload):08x}')
 def test_wrong_firmware_blocks_upload(self):
  before=len(Upstream.uploaded);Upstream.compatible=False
  try:self.assertEqual(self.request('POST','/cluster-api/v1/print_jobs',b'M105\n')[0],502)
  finally:Upstream.compatible=True
  self.assertEqual(len(Upstream.uploaded),before)
 def test_status_heartbeat_during_upload(self):
  self.assertEqual(self.request('GET','/api/v1/system')[0],200)
  Upstream.receiving.clear()
  with ThreadPoolExecutor(max_workers=1) as pool:
   future=pool.submit(self.request,'POST','/cluster-api/v1/print_jobs',b'; diagnostic fixture\n'*512)
   self.assertTrue(Upstream.receiving.wait(3))
   started=time.monotonic();status=self.request('GET','/api/v1/system')
   self.assertEqual(status[0],200);self.assertLess(time.monotonic()-started,.3)
   self.assertEqual(future.result()[0],201)
 def test_unknown_route(self):
  self.assertEqual(self.request('POST','/arbitrary',b'M105\n')[0],404)
 def test_zz_lifecycle(self):
  status,data=self.request('GET','/dreamer-studio/relay')
  self.assertEqual(status,200);self.assertEqual(json.loads(data)['application'],'DreamerStudio')
  self.assertEqual(self.request('POST','/dreamer-studio/stop',b'')[0],403)
  c=http.client.HTTPConnection('127.0.0.1',18897,timeout=5)
  try:
   c.request('POST','/dreamer-studio/stop',body=b'',headers={'X-Dreamer-Studio':'control'})
   r=c.getresponse();self.assertEqual(r.status,202);r.read()
  finally:c.close()

if __name__=='__main__': unittest.main()
