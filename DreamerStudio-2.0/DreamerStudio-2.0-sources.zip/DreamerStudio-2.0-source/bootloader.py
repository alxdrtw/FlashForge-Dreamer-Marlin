"""Existing Dreamer USB bootloader protocol. Never writes the bootloader itself."""
import hashlib,time
import libusb_package,usb.util
from transport import Printer

def install(payload,log=print,progress=lambda n:None,cancel=None,timeout=180,scan=None,sleep=time.sleep,clock=time.monotonic):
    scan=scan or (lambda:list(libusb_package.find(find_all=True)))
    def devices():return [d for d in scan() if d.idVendor==0x0315 and d.idProduct==1]
    deadline=clock()+timeout
    log('Ожидание USB-загрузчика Dreamer, до 3 минут. Выключи принтер на 5 секунд и включи. USB оставь подключённым.')
    if devices():
        log('Обнаружен предыдущий сеанс: жду отключения USB при перезапуске.')
        while clock()<deadline and devices():
            if cancel and cancel.is_set():raise RuntimeError('Ожидание отменено. Прошивка не записывалась.')
            sleep(.05)
    while clock()<deadline:
        if cancel and cancel.is_set():raise RuntimeError('Ожидание отменено. Прошивка не записывалась.')
        found=devices()
        if len(found)>1:raise RuntimeError('Подключено несколько загрузчиков Dreamer. Оставь один принтер.')
        if not found:sleep(.1);continue
        device=found[0];printer=Printer(device=device,log=log)
        try:
            usb.util.claim_interface(device,0)
            for attempt in range(16):
                try:
                    if 'Control Success' not in printer.command('M601 S0',500):raise RuntimeError('Нет подтверждения управления')
                    break
                except Exception:
                    if attempt==15:raise RuntimeError('Загрузчик не предоставил управление. Повтори операцию и перезапуск. Проверь USB-драйвер.')
                    sleep(.1)
            if cancel and cancel.is_set():raise RuntimeError('Ожидание отменено до записи файла.')
            log('Управление получено. Идёт передача; не выключай принтер.')
            reply=printer.command(f'M28 {len(payload)} 0:/sys/firmware.bin')
            if 'Writing to file: dreamer.bin' not in reply:raise RuntimeError('Загрузчик не подтвердил создание файла. Обновление не активировано.')
            for off in range(0,len(payload),16384):
                part=payload[off:off+16384]
                if device.write(3,part,timeout=15000)!=len(part):raise RuntimeError('Неполная передача. Обновление не активировано.')
                progress(.9*(off+len(part))/len(payload))
            if 'Done saving file.' not in printer.command('M29 '+hashlib.md5(payload).hexdigest(),8000):raise RuntimeError('Контрольная сумма не подтверждена. Обновление не активировано.')
            progress(.95)
            if 'succeed' not in printer.command('M600',5000).lower():raise RuntimeError('Активация не подтверждена. Проверь экран принтера и журнал перед повтором.')
            progress(1)
            log('Контрольная сумма подтверждена. Установка активирована. Дождись обновления и главного меню; при необходимости перезапусти вручную.')
            return True
        finally:
            try:printer.command('M602',1000)
            except Exception:pass
            usb.util.dispose_resources(device)
    raise RuntimeError('Загрузчик не обнаружен за 3 минуты. Ничего не записано. Проверь USB, питание и драйвер Dreamer.')
