"""Offline tests: actual Thumb code in Unicorn and fake USB failure cases."""
from pathlib import Path
import itertools, json, struct, unittest
from unittest.mock import patch
from firmware import Options, build, crypt, original, start_gcode, BASE
from transport import Printer
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE
from unicorn.arm_const import *

RAM=0x20000000
def emulator(image):
    u=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
    u.mem_map(0x08000000,0x100000); u.mem_write(BASE,image); u.mem_map(RAM,0x20000)
    u.reg_write(UC_ARM_REG_C1_C0_2, 0xf << 20)
    u.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
    return u
def put(u,addr,value): u.mem_write(addr,struct.pack('<I',value))
def clamp(n,lo,hi): return 0 if n<=0 else max(lo,min(n,hi))

class FirmwareTests(unittest.TestCase):
    def test_actual_clamps(self):
        cases=0
        for o in [Options(),Options(False,False,150,248,160,260,40,100),Options(True,False,280,280,1,1,130,130)]:
            raw,manifest=build(o); image=crypt(raw); u=emulator(image); obj=RAM+0x1000
            self.assertEqual(crypt(image,True),raw)
            for typ,name in [(2,'bed'),(3,'t1'),(4,'t0')]:
                u.mem_write(obj+0x90,bytes([typ]))
                for n in range(-32768,32768):
                    u.reg_write(UC_ARM_REG_R0,obj); u.reg_write(UC_ARM_REG_R1,n & 0xffffffff)
                    u.reg_write(UC_ARM_REG_SP,RAM+0x1f000)
                    u.emu_start((BASE+0x6aa0)|1,BASE+0x6ac4,count=100)
                    self.assertEqual(u.reg_read(UC_ARM_REG_PC),BASE+0x6ac4)
                    self.assertEqual(u.reg_read(UC_ARM_REG_R5),clamp(n,0,getattr(o,name+'_max')))
                    cases+=1
            calls=[]
            def stub(uc,addr,size,data):
                calls.append((uc.reg_read(UC_ARM_REG_R0),uc.reg_read(UC_ARM_REG_R1)))
                uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
            u.hook_add(UC_HOOK_CODE,stub,begin=BASE+0x2f84,end=BASE+0x2f84)
            for selector,name in [(0,'t1'),(1,'t0'),(2,'bed')]:
                for n in range(1000):
                    calls.clear()
                    for addr,value in [(RAM+0x3c4,selector),(RAM+0x3c8,n//100),(RAM+0x3cc,n//10%10),(RAM+0x3d0,n%10)]: put(u,addr,value)
                    u.reg_write(UC_ARM_REG_R4,2); u.reg_write(UC_ARM_REG_R6,0x12345678); u.reg_write(UC_ARM_REG_SP,RAM+0x1f000)
                    u.emu_start((BASE+0x10c54)|1,BASE+0x10cce,count=150)
                    expected=clamp(n,getattr(o,name+'_min'),getattr(o,name+'_max'))
                    self.assertEqual(calls,[({0:1,1:0,2:2}[selector],expected)])
                    self.assertEqual(u.reg_read(UC_ARM_REG_R6),0x12345678)
                    cases+=1
        print('Actual Thumb clamp cases:',cases)

    def test_feature_invariants(self):
        source=crypt(original())
        for ru,parallel in itertools.product([False,True],repeat=2):
            raw,m=build(Options(ru,parallel)); image=crypt(raw)
            self.assertEqual(image[0x6c9c:0x6f16],source[0x6c9c:0x6f16])
            self.assertEqual(image[0x17000:0x1e300],source[0x17000:0x1e300])
            self.assertEqual(image[0x38:0x460],source[0x38:0x460])
            self.assertEqual(image[0x6f2e4:0x7084c]==source[0x6f2e4:0x7084c],not ru)
            for off in [0xed2,0xf4e,0x2076,0x20b0,0x112f6]:
                self.assertEqual(image[off:off+2]==source[off:off+2],not parallel)
            self.assertEqual(raw,build(Options(ru,parallel))[0])

    def test_parallel_paths(self):
        for parallel in [False,True]:
            image=crypt(build(Options(parallel=parallel))[0]); u=emulator(image)
            calls=[]
            def stub(uc,addr,size,data):
                calls.append((addr,uc.reg_read(UC_ARM_REG_R0),uc.reg_read(UC_ARM_REG_R1)))
                # All predicates report bed active but not at target.
                uc.reg_write(UC_ARM_REG_R0,1 if addr==BASE+0x6b9a else 0)
                uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
            for off in [0x6b9a,0x6bba,0x6f16,0x4956,0x4976]:
                u.hook_add(UC_HOOK_CODE,stub,begin=BASE+off,end=BASE+off)
            u.reg_write(UC_ARM_REG_R5,RAM+0x1c88)
            u.emu_start((BASE+0xecc)|1,BASE+0xefc,count=100)
            pauses=[r1 for addr,r0,r1 in calls if addr==BASE+0x6f16]
            self.assertEqual(pauses,[0 if parallel else 1])
            calls.clear()
            u.emu_start((BASE+0xf3e)|1,BASE+0xf5a,count=100)
            self.assertEqual([r0 for addr,r0,r1 in calls if addr==BASE+0x4976],[0 if parallel else 1])
            # Preheat callback is read-only until setter calls, which are stubbed here.
            calls.clear(); obj=RAM+0x1000; put(u,obj+4,0)
            for addr in [RAM+0x3d4,RAM+0x3d5,RAM+0x3d6]: u.mem_write(addr,b'\x01')
            for off,value in [(0xb0,210),(0xb2,220),(0xb4,60)]: u.mem_write(RAM+0xb4+off,struct.pack('<H',value))
            u.hook_add(UC_HOOK_CODE,stub,begin=BASE+0x6aa0,end=BASE+0x6aa0)
            u.reg_write(UC_ARM_REG_R0,obj); u.reg_write(UC_ARM_REG_SP,RAM+0x1f000)
            u.emu_start((BASE+0x112a0)|1,BASE+0x1131a,count=200)
            self.assertEqual([r0 for addr,r0,r1 in calls if addr==BASE+0x4976],[0 if parallel else 1])
            self.assertEqual([r1 for addr,r0,r1 in calls if addr==BASE+0x6aa0],[210,220,60])
            # Print startup bed-wait callers pass zero with parallel mode.
            for off in [0x2076,0x20b0]:
                u.emu_start((BASE+off)|1,BASE+off+2,count=1)
                self.assertEqual(u.reg_read(UC_ARM_REG_R1),0 if parallel else 1)

    def test_validation_and_gcode(self):
        for o in [Options(t0_min=-1),Options(t0_max=281),Options(bed_max=131),Options(t1_min=271),Options(t0_max=0),Options(t0_max=1.5)]:
            with self.assertRaises(ValueError): build(o)
        code=start_gcode(Options(),210,220,60).splitlines()
        self.assertTrue(all(line.startswith(('M140','M104')) for line in code[1:4]))
        self.assertEqual(code[4:],['M7 S600','M6 T0 S600','M6 T1 S600'])
        with self.assertRaises(ValueError): start_gcode(Options(),281,0,60)

    def test_timer_actual_instructions(self):
        raw,manifest=build(Options()); u=emulator(crypt(raw)); tick=[1000]; moves=[]
        def clock(uc,addr,size,data):
            uc.reg_write(UC_ARM_REG_R0,tick[0]); uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
        def enqueue(uc,addr,size,data):
            moves.append((uc.reg_read(UC_ARM_REG_R0),uc.reg_read(UC_ARM_REG_S0)))
            uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
        u.hook_add(UC_HOOK_CODE,clock,begin=BASE+0x3cad0,end=BASE+0x3cad0)
        u.hook_add(UC_HOOK_CODE,enqueue,begin=BASE+0x1d8c6,end=BASE+0x1d8c6)
        def call(off,r0=0,r1=0):
            u.reg_write(UC_ARM_REG_R0,r0); u.reg_write(UC_ARM_REG_R1,r1)
            u.reg_write(UC_ARM_REG_SP,RAM+0x1f000); u.reg_write(UC_ARM_REG_LR,0x080ff001)
            u.emu_start((BASE+off)|1,0x080ff000,count=400)
            self.assertEqual(u.reg_read(UC_ARM_REG_PC),0x080ff000)
            return u.reg_read(UC_ARM_REG_R0)
        timer=RAM+0xfd8
        call(0x3780)
        self.assertEqual(bytes(u.mem_read(timer,4)),b'\x01\x00\x01\x01')
        tick[0]=900_001_000 # 15 minutes heating: display remains zero.
        call(0x30bc,RAM+0x100,RAM+0x101)
        self.assertEqual(bytes(u.mem_read(RAM+0x100,2)),b'\0\0')
        # Travel/no extrusion, retraction and E NaN must not start the timer.
        target=RAM+0xf60
        for relative,tool,requested,current in [(0,0,10.,10.),(0,1,8.,10.),(1,0,0.,10.),(1,1,-1.,10.),(0,0,float('nan'),10.)]:
            u.mem_write(RAM+0x668,bytes([relative]));u.mem_write(RAM+0x11,bytes([tool]))
            u.mem_write(target+12+tool*4,struct.pack('<f',requested));u.mem_write(RAM+0xf74+12+tool*4,struct.pack('<f',current))
            u.reg_write(UC_ARM_REG_R0,target);u.reg_write(UC_ARM_REG_S0,0x42480000);u.reg_write(UC_ARM_REG_SP,RAM+0x1f000)
            u.emu_start((BASE+0x952)|1,BASE+0x956,count=200)
            self.assertEqual(bytes(u.mem_read(timer+3,1)),b'\x01')
            self.assertEqual(moves[-1],(target,0x42480000))
        # Forward absolute extrusion starts the clock once and preserves motion arguments.
        u.mem_write(target+12,struct.pack('<f',11.));u.mem_write(RAM+0x11,b'\0')
        u.reg_write(UC_ARM_REG_R0,target);u.reg_write(UC_ARM_REG_S0,0x42480000)
        u.emu_start((BASE+0x952)|1,BASE+0x956,count=200)
        self.assertEqual(bytes(u.mem_read(timer,4)),b'\x01\x00\x00\x00')
        self.assertEqual(moves[-1],(target,0x42480000))
        tick[0]+=120_000_000
        call(0x30bc,RAM+0x100,RAM+0x101)
        self.assertEqual(bytes(u.mem_read(RAM+0x100,2)),b'\0\x02')
        call(0x5328,timer,1) # Native user pause.
        tick[0]+=180_000_000
        call(0x30bc,RAM+0x100,RAM+0x101)
        self.assertEqual(bytes(u.mem_read(RAM+0x100,2)),b'\0\x02')
        call(0x5328,timer,0)
        tick[0]+=60_000_000
        call(0x30bc,RAM+0x100,RAM+0x101)
        self.assertEqual(bytes(u.mem_read(RAM+0x100,2)),b'\0\x03')
        # A later extrusion cannot reset the running clock.
        start=bytes(u.mem_read(timer+4,4))
        u.reg_write(UC_ARM_REG_R0,target);u.emu_start((BASE+0x952)|1,BASE+0x956,count=200)
        self.assertEqual(bytes(u.mem_read(timer+4,4)),start)
        # New job rearms the marker and zero display.
        call(0x3780);call(0x30bc,RAM+0x100,RAM+0x101)
        self.assertEqual(bytes(u.mem_read(RAM+0x100,2)),b'\0\0')
        u.mem_write(RAM+0x668,b'\x01');u.mem_write(RAM+0x11,b'\x01')
        u.mem_write(target+16,struct.pack('<f',1.))
        u.reg_write(UC_ARM_REG_R0,target);u.reg_write(UC_ARM_REG_S0,0x42480000)
        u.emu_start((BASE+0x952)|1,BASE+0x956,count=200)
        self.assertEqual(bytes(u.mem_read(timer+3,1)),b'\0')
        self.assertEqual(moves[-1],(target,0x42480000))

    def test_timer_disabled_is_stock(self):
        source=crypt(original());image=crypt(build(Options(print_timer=False))[0])
        for off,size in [(0x3786,4),(0x30bc,4),(0x952,4)]:
            self.assertEqual(image[off:off+size],source[off:off+size])

    def test_native_compensation_override(self):
        import math
        stock=crypt(build(Options())[0])
        cases=0
        for a in [0.,.001,.005,.01,.02]:
            image=crypt(build(Options(native_advance=True,native_advance_a=a))[0])
            diffs=[i for i,(x,y) in enumerate(zip(stock,image)) if x!=y]
            self.assertTrue(all(0x1d6da<=i<0x1d6de for i in diffs))
            u=emulator(image);u.reg_write(UC_ARM_REG_R0,1);u.reg_write(UC_ARM_REG_SP,RAM+0x1f000)
            u.emu_start((BASE+0x1d6da)|1,BASE+0x1d6de,count=200)
            af=struct.unpack('<f',struct.pack('<f',a))[0]
            self.assertEqual(struct.unpack('<f',u.mem_read(RAM+0x554,4))[0],af)
            self.assertEqual(bytes(u.mem_read(RAM+0x558,4)),bytes(4))
            self.assertEqual(bytes(u.mem_read(RAM+0x574,1)),b'\x01')
            # Actual native event-rate correction segment; no GPIO and no movement.
            for peak,initial in itertools.product([0,100,1000,5000,10000,20000,40000,80000,160000],repeat=2):
                sp=RAM+0x1f000;u.reg_write(UC_ARM_REG_SP,sp)
                u.reg_write(UC_ARM_REG_R9,peak);u.reg_write(UC_ARM_REG_R5,initial)
                u.emu_start((BASE+0x1bcce)|1,BASE+0x1bd04,count=100)
                actual=struct.unpack('<i',u.mem_read(sp+0x20,4))[0]
                fproduct=struct.unpack('<f',struct.pack('<f',(peak-initial)*af))[0]
                expected=max(0,math.trunc(fproduct))
                self.assertEqual(actual,expected,(a,peak,initial,actual,expected))
                cases+=1
        print('Native compensation arithmetic cases:',cases)
        for a in [float('nan'),float('inf'),-.01,.021]:
            with self.assertRaises(ValueError):build(Options(native_advance=True,native_advance_a=a))

class FakeUSB:
    def __init__(self, failure=None): self.failure=failure; self.commands=[]; self.reply=b''; self.received=bytearray()
    def write(self,ep,data,timeout):
        if ep==3:
            self.received.extend(data); return len(data)-1 if self.failure=='partial' else len(data)
        cmd=data.decode().strip()[1:]; self.commands.append(cmd)
        reply='ok\n'
        if cmd.startswith('M601'):reply='Control Success.\nok\n'
        elif cmd=='M115': reply='Machine Type: Flashforge Dreamer\nTool Count: 2\nFirmware: V2.15 20200917\nok\n' if self.failure!='model' else 'Machine Type: Other\nok\n'
        elif cmd=='M105':reply='T0:20/0 T1:21/0 B:22/'+('60' if self.failure=='hot' else '0')+'\nok\n'
        elif cmd=='M119':reply='MachineStatus: '+('PRINTING' if self.failure=='printing' else 'READY')+'\nMoveMode: READY\nok\n'
        elif cmd.startswith('M28'):reply='Create file failed\nok\n' if self.failure=='create' else f'Writing to file: 0:/sys/dreamer.bin Length: {cmd.split()[1]}\nok\n'
        elif cmd.startswith('M29'):reply='Checksum error\nok\n' if self.failure=='checksum' else 'Done saving file.\nok\n'
        elif cmd=='M600':reply='failed\nok\n' if self.failure=='trigger' else 'succeed\nok\n'
        if self.failure=='timeout' and cmd=='M105': reply='incomplete\n'
        self.reply=reply.encode(); return len(data)
    def read(self,ep,size,timeout):
        if not self.reply:
            import usb.core
            raise usb.core.USBTimeoutError('test timeout')
        chunk=self.reply[:17]; self.reply=self.reply[17:]; return chunk

class USBTests(unittest.TestCase):
    @patch('transport.usb.util.dispose_resources')
    def test_success_and_failures(self,dispose):
        payload=b'firmware test'*3000
        for failure in [None,'model','hot','printing','create','partial','checksum','trigger','timeout']:
            d=FakeUSB(failure)
            try:
                with Printer(device=d) as p: p.upload(payload)
                self.assertIsNone(failure)
            except RuntimeError:
                self.assertIsNotNone(failure)
            if failure not in [None,'trigger']: self.assertNotIn('M600',d.commands)
            if failure is None: self.assertEqual(d.received,payload)
            self.assertEqual(d.commands[-1],'M602')

if __name__=='__main__': unittest.main(verbosity=2)
