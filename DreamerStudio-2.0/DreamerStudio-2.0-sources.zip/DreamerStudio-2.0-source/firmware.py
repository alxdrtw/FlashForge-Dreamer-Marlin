"""Deterministic Dreamer 2.15 patch builder. Never connects to a printer."""
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib, json, sys, math, struct
from Crypto.Cipher import AES
from keystone import Ks, KS_ARCH_ARM, KS_MODE_THUMB

BASE = 0x08010000
ORIGINAL_SHA = 'fbc51d90daf2003135b11fc176f2d07f1bbf628ce0a96c196d7ec71440ed0809'
ASSETS = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'assets'

@dataclass(frozen=True)
class Options:
    russian: bool = True
    parallel: bool = True
    t0_min: int = 0
    t0_max: int = 270
    t1_min: int = 0
    t1_max: int = 270
    bed_min: int = 0
    bed_max: int = 130
    print_timer: bool = True
    native_advance: bool = False
    native_advance_a: float = 0.005

    def validate(self):
        for name, ceiling in [('t0', 280), ('t1', 280), ('bed', 130)]:
            lo, hi = getattr(self, name+'_min'), getattr(self, name+'_max')
            if type(lo) is not int or type(hi) is not int or not 0 <= lo <= hi <= ceiling or hi == 0:
                raise ValueError(f'{name}: требуется 0 ≤ мин ≤ макс ≤ {ceiling}, макс > 0')
        if any(type(x) is not bool for x in (self.russian,self.parallel,self.print_timer,self.native_advance)):
            raise ValueError('Некорректные переключатели')
        if type(self.native_advance_a) not in (float,int) or not math.isfinite(self.native_advance_a) or not 0 <= self.native_advance_a <= .02:
            raise ValueError('Экспериментальный коэффициент A: от 0 до 0.02. Это не Marlin K.')

def crypt(raw, encrypt=False):
    result = bytearray()
    for off in range(0, len(raw), 2048):
        part = raw[off:off+2048]; n = len(part) & ~15
        cipher = AES.new(b'flashforge790315', AES.MODE_CBC, iv=bytes(16))
        result.extend((cipher.encrypt(part[:n]) if encrypt else cipher.decrypt(part[:n])) + part[n:])
    return bytes(result)

def original():
    raw = (ASSETS/'original.bin').read_bytes()
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA:
        raise ValueError('Контрольная сумма исходной прошивки не совпадает')
    return raw

def build(options):
    options.validate()
    source = original(); plain = crypt(source)
    image = bytearray(plain); edits = []; allowed = set()
    ks = Ks(KS_ARCH_ARM, KS_MODE_THUMB)
    def asm(code, off):
        return bytes(ks.asm(code, addr=BASE+off)[0])
    def replace(off, expected, new, purpose):
        if plain[off:off+len(expected)] != expected or len(expected) != len(new):
            raise ValueError(f'Неожиданные инструкции по смещению {off:x}')
        image[off:off+len(new)] = new
        allowed.update(range(off, off+len(new)))
        edits.append(dict(offset=hex(off), before=expected.hex(), after=new.hex(), purpose=purpose))
    def helper(code):
        off = len(image)
        image.extend(asm(code, off))
        while len(image) % 4: image.extend(b'\x00\xbf')
        return off
    def clamp_code(reg, lo, hi, ret):
        return (f'cmp {reg}, #0; ble off; movw r6, #{hi}; cmp {reg}, r6; '
                f'ble lower; mov {reg}, r6; lower: movw r6, #{lo}; '
                f'cmp {reg}, r6; bge done; mov {reg}, r6; b done; '
                f'off: movs {reg}, #0; done: b.w #{BASE+ret}')
    # Original setter prologue has already loaded the signed request into r5 and type into r0.
    common = 'cmp r0, #2; beq bed; cmp r0, #3; beq t1; '
    # UI minimum must NOT raise internal pause/standby targets to the menu minimum.
    common += clamp_code('r5', 0, options.t0_max, 0x6ac4).replace('off','a_off').replace('lower','a_lower').replace('done','a_done')
    common += '; t1: ' + clamp_code('r5', 0, options.t1_max, 0x6ac4).replace('off','b_off').replace('lower','b_lower').replace('done','b_done')
    common += '; bed: ' + clamp_code('r5', 0, options.bed_max, 0x6ac4).replace('off','c_off').replace('lower','c_lower').replace('done','c_done')
    target = helper(common)
    replace(0x6aaa, plain[0x6aaa:0x6ac4], asm(f'b.w #{BASE+target}; '+ '; '.join(['nop']*11), 0x6aaa), 'Independent signed setpoint limits; zero always off')
    for off, name in [(0x10c78, 't1'), (0x10c96, 't0'), (0x10cba, 'bed')]:
        code = clamp_code('r5', getattr(options,name+'_min'), getattr(options,name+'_max'), off+6)
        target = helper('push {r6}; ' + code.replace('done: b.w', 'done: pop {r6}; b.w'))
        replace(off, plain[off:off+6], asm(f'b.w #{BASE+target}; nop', off), name+' numeric UI limits')
    if options.parallel:
        # Only bed-wait callers are changed. The general pause/resume and fault paths remain intact.
        for off, before, code, why in [
            (0xed2, '78b1', f'b #{BASE+0xef4}', 'M104: do not pause nozzle while bed heats'),
            (0xf4e, '0124', 'movs r4, #0', 'M140: do not pause both nozzles'),
            (0x2076, '0121', 'movs r1, #0', 'Print startup: T0 does not wait for bed'),
            (0x20b0, '0121', 'movs r1, #0', 'Print startup: T1 does not wait for bed'),
            (0x112f6, '0120', 'movs r0, #0', 'Screen preheat: do not pause nozzles for bed')]:
            replace(off, bytes.fromhex(before), asm(code, off), why)
    if options.print_timer:
        # Timer 0x20000FD8: bool active, expired, paused, padding; uint32 start, period, elapsed.
        # Its padding byte is used solely as a pending-first-extrusion marker. No new RAM allocation.
        timer_init = helper(f'push {{r4, lr}}; mov r4, r0; bl #{BASE+0x52d4}; '
                            'movs r1, #1; strb r1, [r4, #3]; strb r1, [r4, #2]; pop {r4, pc}')
        replace(0x3786, bytes.fromhex('01f0a5fd'), asm(f'bl #{BASE+timer_init}',0x3786), 'Arm timer, hold at zero until first forward extrusion')
        timer_read = helper('movw r2, #0xfd8; movt r2, #0x2000; ldrb r3, [r2, #3]; '
                            'cmp r3, #1; bne native; movs r2, #0; strb r2, [r0]; strb r2, [r1]; bx lr; '
                            f'native: push {{r4, r5, r6, lr}}; mov r4, r0; b.w #{BASE+0x30c0}')
        replace(0x30bc, bytes.fromhex('70b50446'), asm(f'b.w #{BASE+timer_read}',0x30bc), 'Display zero before first extrusion; native elapsed display thereafter')
        # G0/G1's call to enqueue the parsed motion. Preserve original target pointer, speed and volatile registers.
        timer_motion = helper('push {r0-r4, lr}; vpush {s0-s3}; '
                              'movw r4, #0xfd8; movt r4, #0x2000; '
                              'ldrb r1, [r4]; cmp r1, #1; bne done; '
                              'ldrb r1, [r4, #3]; cmp r1, #1; bne done; '
                              'movw r1, #0x11; movt r1, #0x2000; ldrb r1, [r1]; '
                              'cmp r1, #0; ite eq; addeq r0, r0, #12; addne r0, r0, #16; vldr s0, [r0]; '
                              'movw r2, #0x668; movt r2, #0x2000; ldrb r2, [r2]; '
                              'cmp r2, #0; beq absolute; vcmp.f32 s0, #0; b checked; '
                              'absolute: movw r2, #0xf74; movt r2, #0x2000; '
                              'cmp r1, #0; ite eq; addeq r2, r2, #12; addne r2, r2, #16; '
                              'vldr s1, [r2]; vcmp.f32 s0, s1; '
                              'checked: vmrs APSR_nzcv, fpscr; ble done; bvs done; '
                              'mov r0, r4; movw r1, #0xa400; movt r1, #0xd693; '
                              f'bl #{BASE+0x52d4}; movs r1, #0; strb r1, [r4, #3]; '
                              'movw r2, #0x1ac; movt r2, #0x2000; strb r1, [r2]; '
                              'done: vpop {s0-s3}; pop {r0-r4, lr}; '
                              f'b.w #{BASE+0x1d8c6}')
        replace(0x952,bytes.fromhex('1cf0b8ff'),asm(f'bl #{BASE+timer_motion}',0x952), 'Start timer once on first queued forward extrusion, including purge')
    if options.native_advance:
        # Native firmware already has an extrusion-compensation engine. Override its initializer inputs,
        # never the interrupt code or Wi-Fi. A is a native event-rate coefficient, NOT Marlin M900 K.
        bits=struct.unpack('<I',struct.pack('<f',options.native_advance_a))[0]
        advance_init=helper(f'movw r2, #{bits & 65535}; movt r2, #{bits >> 16}; vmov s0, r2; '
                            f'movs r2, #0; vmov s1, r2; b.w #{BASE+0x1c1ae}')
        replace(0x1d6da,bytes.fromhex('fef768fd'),asm(f'bl #{BASE+advance_init}',0x1d6da),
                'EXPERIMENT: native compensation A override; nonlinear B=0; not Marlin Linear Advance')
    if options.russian:
        manifest = json.loads((ASSETS/'translation.json').read_text(encoding='utf-8'))
        for field in manifest['fields']:
            off = int(field['offset'],16); size = field['slot_bytes']
            raw = field['russian'].encode('utf-8')
            if len(raw) >= size: raise ValueError('Перевод не помещается в поле')
            replace(off, plain[off:off+size], raw+bytes(size-len(raw)), 'Russian UI')
        for base in [0x6dd7c,0x6f2e4,0x7084c,0x71db4,0x7331c,0x74884,0x75dec,0x77354,0x788bc,0x79e24,0x7b38c]:
            off=base+0x1ec
            # English block was already translated above.
            if off in allowed: continue
            replace(off, b'English\0\0\0', 'Рус.'.encode()+bytes(3), 'Language selector')
    assert image[0x6c9c:0x6f16] == plain[0x6c9c:0x6f16], 'Fault protection changed'
    assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(plain,image)))
    assert BASE+len(image) < 0x08100000
    encrypted=crypt(image, True)
    assert crypt(encrypted) == image
    return encrypted, dict(format=1, original_sha256=ORIGINAL_SHA, options=asdict(options),
                          sha256=hashlib.sha256(encrypted).hexdigest(), size=len(encrypted),
                          protection_unchanged=True, patches=edits,
                          native_advance_status='experimental native engine, NOT Marlin Linear Advance; hardware untested' if options.native_advance else 'stock native coefficients unchanged',
                          note='Custom configuration requires hardware verification. Native temperature waits are retained.')

def start_gcode(options, t0=210, t1=0, bed=60):
    options.validate()
    for name, value in [('t0',t0),('t1',t1),('bed',bed)]:
        if type(value) is not int or value < 0 or (value and not getattr(options,name+'_min') <= value <= getattr(options,name+'_max')):
            raise ValueError(f'{name}: температура вне выбранного диапазона')
    # All nonblocking targets precede all waits. Never changes motion or endstops.
    lines=['; Dreamer native protocol: insert BEFORE the first temperature wait',
           f'M140 S{bed}',f'M104 S{t0} T0',f'M104 S{t1} T1']
    if bed: lines.append('M7 S600')
    if t0: lines.append('M6 T0 S600')
    if t1: lines.append('M6 T1 S600')
    return '\n'.join(lines)+'\n'
