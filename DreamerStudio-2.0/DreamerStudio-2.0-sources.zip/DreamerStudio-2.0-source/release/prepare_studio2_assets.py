from pathlib import Path
import configparser,hashlib,io,json,shutil,sys,zipfile
root=Path(__file__).resolve().parent.parent
source=root/'work/DreamerStudio2';assets=source/'assets'
sys.path.insert(0,str(source))
from firmware import Options,build,original
marlin=root/'outputs/Marlin-Cura-WiFi-TEST'
for src,dst in [('DREAMER_MARLIN_CURA_WIFI_TEST.bin','marlin.bin'),('ROLLBACK_MARLIN_WORKING.bin','rollback-marlin.bin'),('ROLLBACK_RU270.bin','rollback-ru.bin')]:shutil.copyfile(marlin/src,assets/dst)
assert hashlib.sha256((assets/'marlin.bin').read_bytes()).hexdigest()=='b25d2a4a3a41e2d63992d1713bafa41b3625393495065dffbaf4a98d5ea9eef8'
shutil.copyfile(source/'manual.html',assets/'manual.html')
config=Path('C:/Users/User/AppData/Roaming/cura/5.13')
bundle=root/'Cura';job=root/'Печать/Куб 10мм'
with zipfile.ZipFile(assets/'bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(source/'manual.html','Инструкция.html')
    for sub in ('definitions','extruders','machine_instances','user','definition_changes'):
        for path in (config/sub).glob('pih_a*'):
            if not path.is_file():continue
            data=path.read_bytes()
            if sub=='machine_instances':
                c=configparser.ConfigParser(interpolation=None);c.read_string(data.decode('utf-8'))
                c['metadata'].pop('is_online',None);c['metadata'].pop('group_id',None)
                c['metadata']['um_network_key']='manual:127.0.0.1:18899'
                stream=io.StringIO();c.write(stream);data=stream.getvalue().encode()
            z.writestr('Cura-install/'+sub+'/'+path.name,data)
    for name in ('FlashPrint-Standard-Dreamer.curaprofile','FlashPrint-Standard-original.ini','conversion-map.csv','not-converted.json'):
        z.write(bundle/name,'Profiles/'+name)
    for name in ('Dreamer_ABS_LEFT_TUNED.3mf','cube_10x10x10.stl','cura-job-settings.json'):
        z.write(job/name,'Profiles/'+name)
    # Portable quality_changes profile, derived from exactly the installed tuned user containers.
    profile=io.BytesIO()
    with zipfile.ZipFile(profile,'w',zipfile.ZIP_DEFLATED) as p:
        for suffix,position in (('',None),('_T0',0),('_T1',1)):
            c=configparser.ConfigParser(interpolation=None);c.read(config/'user'/f'pih_a_dreamer_abs_left{suffix}_user.inst.cfg',encoding='utf-8')
            c['general']['name']='Dreamer ABS LEFT Tuned 220-105'
            c['general']['definition']='fdmprinter'
            c['metadata']={'type':'quality_changes','quality_type':'normal','setting_version':'27',**({'position':str(position)} if position is not None else {})}
            stream=io.StringIO();c.write(stream);p.writestr(f'abs_left_tuned{suffix}.inst.cfg',stream.getvalue())
    z.writestr('Profiles/Dreamer-ABS-LEFT-Tuned.curaprofile',profile.getvalue())
    payload,native=build(Options())
    z.writestr('Firmware/native-270-ru-parallel-timer.bin',payload)
    z.writestr('Profiles/native-270-ru-parallel-timer.json',json.dumps(native['options'],indent=2))
    z.writestr('Firmware/ORIGINAL_DREAMER_2.15.bin',original())
    z.write(marlin/'Marlin-Cura-WiFi-sources.zip','Sources/Marlin-Cura-WiFi-sources.zip')
    z.write(marlin/'LICENSE-GPL-3.0.txt','Sources/LICENSE-Marlin-GPL-3.0.txt')
    z.write(marlin/'manifest.json','Firmware/Marlin-hardware-verification.json')
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in assets.iterdir() if p.is_file() and p.name!='suite-manifest.json'}
(assets/'suite-manifest.json').write_text(json.dumps({'version':'2.0','files':files},indent=2),encoding='utf-8')
print('Bundled resources:',len(files),'files;',sum(p.stat().st_size for p in assets.iterdir() if p.is_file()),'bytes')
