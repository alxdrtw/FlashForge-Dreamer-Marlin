"""Loopback Cura API relay. Serializes requests for the stock broadcast Wi-Fi module.

No motion, heating, file upload, or print request is generated automatically.
Requires the Dreamer Cura API firmware; never forwards uploads to raw Marlin.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse, http.client, json, threading, tempfile, time, socket, zlib, os

LOCK = threading.Lock()
MAX_BODY = 64 * 1024 * 1024

def serve(host='192.168.88.222', printer_port=8899, port=18899):
 cache = {}; uploading = threading.Event(); stopping = threading.Event()
 class Handler(BaseHTTPRequestHandler):
  def log_message(self, *_): pass
  def answer(self, status, data, kind='application/json'):
   self.send_response(status)
   self.send_header('Content-Type', kind)
   self.send_header('Content-Length', str(len(data)))
   self.send_header('Connection', 'close')
   self.end_headers()
   self.wfile.write(data)
  def handle_request(self):
   if self.path == '/dreamer-studio/relay' and self.command == 'GET':
    return self.answer(200,json.dumps({'application':'DreamerStudio','version':'2.0','host':host,'printer_port':printer_port,'pid':os.getpid(),'uploading':uploading.is_set()}).encode())
   if self.path == '/dreamer-studio/stop' and self.command == 'POST':
    if self.headers.get('X-Dreamer-Studio')!='control':return self.answer(403,b'{}')
    if uploading.is_set():return self.answer(409,b'{"error":"Upload in progress"}')
    with LOCK:stopping.set()
    self.answer(202,b'{}');threading.Thread(target=server.shutdown,daemon=True).start();return
   if stopping.is_set():return self.answer(503,b'{"error":"Relay stopping"}')
   allowed = {'/api/v1/system', '/api/v1/printer', '/cluster-api/v1/printers',
              '/cluster-api/v1/print_jobs', '/cluster-api/v1/materials'}
   path = self.path.rstrip('/')
   if path not in allowed and path not in {
    '/cluster-api/v1/print_jobs/dreamer-current-job',
    '/cluster-api/v1/print_jobs/dreamer-current-job/action'}:
    return self.answer(404, b'{"error":"Unsupported route"}')
   # The printer has not started the new SD job while bytes are arriving.
   # Keep Cura's status heartbeat alive during a long, exclusive upload using
   # the last successful read; refresh from hardware as soon as upload finishes.
   if self.command == 'GET' and uploading.is_set() and path in cache:
    status, data, kind = cache[path]
    return self.answer(status, data, kind)
   try:
    if self.headers.get('Transfer-Encoding'):
     return self.answer(411, b'{"error":"Content-Length required"}')
    size = int(self.headers.get('Content-Length', '0'))
    if not 0 <= size <= MAX_BODY:
     return self.answer(413, b'{"error":"Body too large"}')
    self.connection.settimeout(30)
    with tempfile.SpooledTemporaryFile(max_size=1024*1024) as body:
     remaining = size; crc = 0
     while remaining:
      block = self.rfile.read(min(65536, remaining))
      if not block: raise ConnectionError('Incomplete request body')
      body.write(block); remaining -= len(block); crc = zlib.crc32(block, crc)
     body.seek(0)
     with LOCK:
      if stopping.is_set():return self.answer(503,b'{"error":"Relay stopping"}')
      upload = self.command == 'POST' and path == '/cluster-api/v1/print_jobs'
      if upload:
       check = http.client.HTTPConnection(host, printer_port, timeout=8)
       try:
        check.request('GET', '/api/v1/system', headers={'Connection':'close'})
        response = check.getresponse()
        system = json.loads(response.read(8192))
        if response.status != 200 or 'Cura local API' not in system.get('platform', ''):
         raise ValueError('Compatible Dreamer firmware required')
       finally: check.close()
       uploading.set()
      upstream = http.client.HTTPConnection(host, printer_port, timeout=30)
      try:
       upstream.putrequest(self.command, self.path)
       upstream.putheader('Connection', 'close')
       upstream.putheader('Content-Length', str(size))
       upstream.putheader('Content-Type', self.headers.get('Content-Type', 'application/json'))
       if upload: upstream.putheader('X-Dreamer-CRC32', f'{crc:08x}')
       upstream.endheaders()
       if upload: upstream.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
       while True:
        block = body.read(256 if upload else 1024)
        if not block: break
        upstream.send(block)
        if upload: time.sleep(.040)
       response = upstream.getresponse()
       data = response.read(65537)
       if len(data) > 65536: raise ValueError('Oversized printer response')
       kind=response.getheader('Content-Type', 'application/json')
       if self.command == 'GET' and response.status == 200: cache[path]=(response.status,data,kind)
       self.answer(response.status, data, kind)
      finally:
       upstream.close()
       if upload: uploading.clear()
   except (OSError, ValueError, http.client.HTTPException):
    self.answer(502, b'{"error":"Printer unavailable or compatible Cura firmware not installed"}')
  do_GET = do_POST = do_PUT = do_DELETE = handle_request
 server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
 server.daemon_threads = True
 print(f'Dreamer Cura relay: 127.0.0.1:{port} -> {host}:{printer_port}', flush=True)
 server.serve_forever()

if __name__ == '__main__':
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--host', default='192.168.88.222')
 parser.add_argument('--printer-port', type=int, default=8899)
 parser.add_argument('--port', type=int, default=18899)
 args = parser.parse_args()
 serve(args.host, args.printer_port, args.port)
