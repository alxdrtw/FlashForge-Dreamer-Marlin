"""Bundled, hash-checked resources and portable Cura configuration. No automatic flashing."""
from pathlib import Path
import configparser,datetime,hashlib,ipaddress,json,os,shutil,socket,subprocess,sys,zipfile,uuid
from firmware import ASSETS

DATA=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'DreamerStudio'
MACHINE='pih_a_flashforge_dreamer_marlin'
STACK='pih_a_dreamer_abs_left'

def manifest():return json.loads((ASSETS/'suite-manifest.json').read_text(encoding='utf-8'))
def checked(name):
    data=(ASSETS/name).read_bytes()
    if hashlib.sha256(data).hexdigest()!=manifest()['files'][name]:raise ValueError('Повреждён встроенный файл: '+name)
    return data
def verify():
    for name in manifest()['files']:checked(name)
    return manifest()
def export_bundle(folder):
    folder=Path(folder)/'DreamerStudio-2.0';folder.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ASSETS/'bundle.zip') as archive:
        checked('bundle.zip')
        for entry in archive.infolist():
            target=(folder/entry.filename).resolve()
            if not target.is_relative_to(folder.resolve()):raise ValueError('Недопустимый путь в комплекте')
        archive.extractall(folder)
    (folder/'DREAMER_MARLIN_CURA_WIFI.bin').write_bytes(checked('marlin.bin'))
    (folder/'ROLLBACK_MARLIN_WORKING.bin').write_bytes(checked('rollback-marlin.bin'))
    (folder/'ROLLBACK_RU270.bin').write_bytes(checked('rollback-ru.bin'))
    return folder
def guide():
    target=DATA/'manual-2.0.html';target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(checked('manual.html'));os.startfile(target)
def validate_ip(value):return str(ipaddress.IPv4Address(value.strip()))
def saved_host():
    try:return validate_ip(json.loads((DATA/'wifi.json').read_text(encoding='utf-8'))['host'])
    except FileNotFoundError:return '192.168.88.222'
def cura_dirs():
    base=Path(os.environ.get('APPDATA',Path.home()))/'cura'
    return [p for p in base.glob('5.13*') if p.is_dir()] if base.exists() else []
def cura_running():
    # Read-only process inventory; never stop Cura or discard its workspace.
    result=subprocess.run(['tasklist','/FI','IMAGENAME eq UltiMaker-Cura.exe','/FO','CSV','/NH'],capture_output=True,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return 'ultimaker-cura.exe' in result.stdout.lower()
def install_cura(config=None,address='127.0.0.1:18899',check_running=True):
    if check_running and cura_running():raise RuntimeError('Закрой Cura перед установкой профилей: открытая Cura может перезаписать конфигурацию. Программа не будет закрывать её автоматически.')
    if address!='127.0.0.1:18899':raise ValueError('Для штатного Wi-Fi используется локальный мост 127.0.0.1:18899')
    options=cura_dirs()
    config=Path(config) if config is not None else (options[0] if len(options)==1 else None)
    if config is None:raise RuntimeError('Не найдена единственная папка Cura 5.13. Установи и один раз запусти Cura 5.13, затем закрой её. Профили можно также экспортировать для ручной установки.')
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup=config/'backups'/('DreamerStudio-2.0-'+stamp);backup.mkdir(parents=True)
    old_stack=configparser.ConfigParser(interpolation=None)
    old_stack.read(config/'machine_instances'/(STACK+'.global.cfg'),encoding='utf-8')
    with zipfile.ZipFile(ASSETS/'bundle.zip') as archive:
        checked('bundle.zip')
        for name in archive.namelist():
            if not name.startswith('Cura-install/'):continue
            relative=Path(name.removeprefix('Cura-install/'))
            if '..' in relative.parts or relative.is_absolute():raise ValueError('Недопустимый путь профиля')
            target=config/relative
            if target.exists():
                saved=backup/relative;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(target,saved)
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(archive.read(name))
    stack_path=config/'machine_instances'/(STACK+'.global.cfg')
    stack=configparser.ConfigParser(interpolation=None);stack.read(stack_path,encoding='utf-8')
    stack['metadata']['group_id']=old_stack.get('metadata','group_id',fallback=str(uuid.uuid4()))
    with stack_path.open('w',encoding='utf-8') as stream:stack.write(stream)
    prefs=config/'cura.cfg';cfg=configparser.ConfigParser(interpolation=None)
    cfg.read(prefs,encoding='utf-8')
    if prefs.exists():shutil.copyfile(prefs,backup/'cura.cfg')
    for section in ('cura','um3networkprinting'):
        if not cfg.has_section(section):cfg.add_section(section)
    cfg['cura']['active_machine']=STACK
    existing=[v.strip() for v in cfg['um3networkprinting'].get('manual_instances','').split(',') if v.strip() and v.strip()!=address]
    cfg['um3networkprinting']['manual_instances']=','.join(existing+[address])
    with prefs.open('w',encoding='utf-8') as stream:cfg.write(stream)
    return 'Профиль установлен в '+str(config)+'\nРезервная копия: '+str(backup)+'\nЗапусти Wi-Fi-мост, затем Cura. Активно левое T1, ABS 220/105; правое T0 отключено.'
def relay_status(host):
    import http.client
    c=http.client.HTTPConnection('127.0.0.1',18899,timeout=4)
    try:
        c.request('GET','/api/v1/system');response=c.getresponse();data=json.loads(response.read(8192))
        if response.status!=200 or 'Cura local API' not in data.get('platform',''):raise ValueError('Порт 18899 занят другим приложением или несовместимой версией моста')
        return data
    finally:c.close()
def relay_info():
    import http.client
    c=http.client.HTTPConnection('127.0.0.1',18899,timeout=3)
    try:
        c.request('GET','/dreamer-studio/relay');r=c.getresponse();data=json.loads(r.read(8192))
        if r.status!=200 or data.get('application')!='DreamerStudio':raise ValueError('Порт занят прежним мостом или другим приложением. Закрой его перед запуском Studio 2.0.')
        return data
    finally:c.close()
def stop_relay():
    import http.client
    relay_info()
    c=http.client.HTTPConnection('127.0.0.1',18899,timeout=4)
    try:
        c.request('POST','/dreamer-studio/stop',body=b'',headers={'X-Dreamer-Studio':'control'});r=c.getresponse();r.read()
        if r.status!=202:raise RuntimeError('Мост занят передачей файла. Дождись окончания загрузки.')
        return 'Wi-Fi-мост остановлен. Печать уже загруженного файла с SD продолжается.'
    finally:c.close()
def start_relay(host):
    host=validate_ip(host)
    with socket.socket() as test:busy=test.connect_ex(('127.0.0.1',18899))==0
    if busy:
        info=relay_info()
        if info['host']!=host:raise ValueError('Мост уже работает с IP '+info['host']+'. Останови его и запусти с новым IP.')
        return 'Мост уже запущен для '+host+'. Нажми «Проверить Wi-Fi» для проверки принтера.'
    DATA.mkdir(parents=True,exist_ok=True)
    (DATA/'wifi.json').write_text(json.dumps({'host':host}),encoding='utf-8')
    command=[sys.executable,'--wifi-relay','--host',host] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).with_name('app.py')),'--wifi-relay','--host',host]
    environment=os.environ.copy()
    if getattr(sys,'frozen',False):environment['PYINSTALLER_RESET_ENVIRONMENT']='1'
    process=subprocess.Popen(command,env=environment,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    (DATA/'relay-process.json').write_text(json.dumps({'pid':process.pid,'host':host}),encoding='utf-8')
    return 'Wi-Fi-мост запущен в фоне: 127.0.0.1:18899 → '+host+':8899. Он продолжит работать после закрытия Studio. Нажми «Проверить Wi-Fi» через несколько секунд.'
def probe_usb():
    import serial,serial.tools.list_ports,time
    ports=[p for p in serial.tools.list_ports.comports() if p.vid==0x0483 and p.pid==0x5740]
    if len(ports)>1:raise RuntimeError('Обнаружено несколько STM32 CDC. Оставь подключённым один Dreamer.')
    if ports:
        with serial.Serial(ports[0].device,250000,timeout=.2,write_timeout=2) as port:
            def command(text):
                port.reset_input_buffer();port.write((text+'\n').encode());data=b'';deadline=time.monotonic()+5
                while time.monotonic()<deadline:
                    data+=port.read(8192)
                    if b'\nok\n' in data.replace(b'\r',b'') or data.startswith(b'ok '):break
                return data.decode(errors='replace')
            identity=command('M115')
            if 'MACHINE_TYPE:FlashForge' not in identity or 'Marlin' not in identity:raise RuntimeError('CDC-устройство не подтвердило Marlin для FlashForge.')
            return identity+'\n'+command('M105')+'\n'+command('M795')
    from transport import Printer
    with Printer() as printer:
        result=printer.inspect();return result['temperatures']+'\n'+result['status']

def launch_cura():
    candidates=list(Path(os.environ.get('ProgramFiles','C:/Program Files')).glob('UltiMaker Cura 5.13*/UltiMaker-Cura.exe'))
    if len(candidates)!=1:raise RuntimeError('Не найдена единственная Cura 5.13 в Program Files. Запусти установленную Cura вручную.')
    os.startfile(candidates[0])
