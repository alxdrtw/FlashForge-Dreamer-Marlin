"""Dreamer Studio — portable firmware builder and USB loader."""
from pathlib import Path
from dataclasses import asdict
import hashlib, json, os, queue, sys, threading
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
from firmware import Options, build, original, start_gcode
from transport import Printer
import suite,bootloader

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')
BG='#0b101b'; CARD='#141d2d'; MUTED='#93a4bd'; ACCENT='#4d8eff'; GREEN='#49dcb1'
DATA=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'DreamerStudio'

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('Dreamer Studio 2.0 · Всё для Dreamer'); self.geometry('1180x900'); self.minsize(1080,780)
        self.cancel_wait=threading.Event()
        self.configure(fg_color=BG); self.events=queue.Queue(); self.busy=False; self.controls=[]
        self.protocol('WM_DELETE_WINDOW',self.close)
        self.grid_columnconfigure(1,weight=1); self.grid_rowconfigure(0,weight=1)
        side=ctk.CTkFrame(self,width=210,corner_radius=0,fg_color='#101827'); side.grid(row=0,column=0,sticky='ns'); side.grid_propagate(False)
        self.label(side,'D / STUDIO',26,'white',pady=(35,6))
        self.label(side,'FLASHFORGE DREAMER',11,MUTED,pady=(0,40))
        self.label(side,'MARLIN + WI-FI\nCURA + ПРОФИЛИ\nШТАТНАЯ ПРОШИВКА',15,ACCENT,pady=12)
        self.label(side,'Два сопла / USB / Wi-Fi\nWindows x64\nБез Python',12,MUTED,pady=(60,12))
        self.label(side,'@pih_a\nЕдиный комплект 2.0',14,GREEN,pady=15)
        self.tabs=ctk.CTkTabview(self,fg_color=BG);self.tabs.grid(row=0,column=1,sticky='nsew',padx=15,pady=(6,0))
        hub=self.tabs.add('Marlin · Cura · Wi-Fi');native=self.tabs.add('Штатная прошивка')
        native.grid_columnconfigure(0,weight=1);native.grid_rowconfigure(0,weight=1)
        self.make_hub(hub)
        main=ctk.CTkScrollableFrame(native,fg_color=BG,corner_radius=0); main.grid(row=0,column=0,sticky='nsew')
        main.grid_columnconfigure(0,weight=1)
        self.label(main,'Сборщик штатной V2.15',27,'white',anchor='w',pady=(5,3))
        self.label(main,'Эти галки и диапазоны относятся только к штатной прошивке. Marlin устанавливается готовой сборкой на соседней вкладке.',12,MUTED,anchor='w',pady=(0,18))
        card=self.card(main)
        self.russian=tk.BooleanVar(value=True); self.parallel=tk.BooleanVar(value=True); self.print_timer=tk.BooleanVar(value=True); self.native_advance=tk.BooleanVar(value=False)
        self.check(card,'Русский интерфейс',self.russian,'Перевод меню, сообщений и диалогов вместо English')
        self.check(card,'Одновременный нагрев',self.parallel,'Сопла не ждут стол: преднагрев с экрана и запуск печати')
        self.label(card,'Для печати также вставь стартовый G-code до первого ожидания нагрева.',12,MUTED,anchor='w',pady=(0,14))
        self.check(card,'Таймер с начала печати',self.print_timer,'От первой команды подачи пластика, включая продувку. Без начального нагрева.')
        self.check(card,'Компенсация подачи · эксперимент',self.native_advance,'Штатный механизм Dreamer. Сохраняет Wi-Fi. Это не Marlin Linear Advance.')
        advance_row=ctk.CTkFrame(card,fg_color='transparent'); advance_row.pack(fill='x',padx=18,pady=(4,14))
        ctk.CTkLabel(advance_row,text='Коэффициент A (0…0.02)',text_color=MUTED).pack(side='left',padx=(0,12))
        self.advance_entry=ctk.CTkEntry(advance_row,width=100);self.advance_entry.insert(0,'0.005');self.advance_entry.pack(side='left');self.controls.append(self.advance_entry)
        card=self.card(main)
        self.label(card,'ДИАПАЗОНЫ ТЕМПЕРАТУР',12,MUTED,anchor='w',pady=(14,10))
        grid=ctk.CTkFrame(card,fg_color='transparent'); grid.pack(fill='x',padx=18,pady=(0,10))
        self.entries={}
        for col,text in enumerate(['Нагреватель','Мин., °C','Макс., °C','Предел загрузчика']):
            ctk.CTkLabel(grid,text=text,text_color=MUTED).grid(row=0,column=col,padx=12,pady=4,sticky='w')
        grid.grid_columnconfigure(0,weight=1)
        for row,(name,title,limit) in enumerate([('t0','Сопло T0',280),('t1','Сопло T1',280),('bed','Стол',130)],1):
            ctk.CTkLabel(grid,text=title,font=('Segoe UI',15)).grid(row=row,column=0,padx=12,pady=8,sticky='w')
            for col,key,value in [(1,name+'_min',0),(2,name+'_max',130 if name=='bed' else 270)]:
                entry=ctk.CTkEntry(grid,width=95,height=36); entry.insert(0,str(value)); entry.grid(row=row,column=col,padx=12,pady=5)
                self.entries[key]=entry; self.controls.append(entry)
            ctk.CTkLabel(grid,text=f'до {limit} °C',text_color=MUTED).grid(row=row,column=3,padx=12)
        self.label(card,'0 °C всегда выключает нагрев. Мин. действует при вводе числа в меню.\nЭто не пороги датчиков. Аварийные защиты остаются штатными.',12,MUTED,anchor='w',pady=(0,14))
        actions=ctk.CTkFrame(main,fg_color='transparent'); actions.pack(fill='x',pady=(10,8))
        self.button(actions,'Сохранить .BIN',self.export,ACCENT).pack(side='left',padx=(0,8))
        self.button(actions,'Стартовый G-code',self.gcode,'#253750').pack(side='left',padx=4)
        self.button(actions,'Профиль ↓',self.save_profile,'#253750',width=95).pack(side='left',padx=4)
        self.button(actions,'Профиль ↑',self.load_profile,'#253750',width=95).pack(side='left',padx=4)
        footer=ctk.CTkFrame(self,fg_color=BG);footer.grid(row=1,column=1,sticky='ew',padx=15,pady=(0,8))
        card=self.card(footer)
        top=ctk.CTkFrame(card,fg_color='transparent'); top.pack(fill='x',padx=18,pady=(10,4))
        self.status=ctk.CTkLabel(top,text='●  Принтер не проверен',text_color=MUTED,font=('Segoe UI',14)); self.status.pack(side='left')
        self.button(top,'Проверить USB',self.probe,'#253750',width=130).pack(side='right')
        self.cancel_button=self.button(top,'Отменить ожидание',lambda:self.cancel_wait.set(),'#253750',width=145)
        self.cancel_button.pack(side='right',padx=8);self.controls.remove(self.cancel_button)
        self.bar=ctk.CTkProgressBar(card,progress_color=GREEN); self.bar.pack(fill='x',padx=18,pady=8); self.bar.set(0)
        self.logbox=ctk.CTkTextbox(card,height=100,fg_color='#0c1320',font=('Consolas',11),text_color='#b9cce5'); self.logbox.pack(fill='x',padx=18,pady=6); self.logbox.configure(state='disabled')
        self.log('Включи принтер, закрой FlashPrint и подключи USB. Проверка не двигает оси и не включает нагрев.')
        bottom=ctk.CTkFrame(card,fg_color='transparent'); bottom.pack(fill='x',padx=18,pady=(6,18))
        self.button(bottom,'Установить штатную с выбранными настройками',self.install,'#253750',width=340).pack(side='left')
        self.button(bottom,'Вернуть оригинал',self.rollback,'#253750',width=165).pack(side='right')
        self.label(main,'После передачи: вручную выключи и включи принтер, дождись окончания обновления.\nСборка и экспорт не обращаются к принтеру. Установка не запускает нагрев.',12,MUTED,anchor='w',pady=10)
        self.after(100,self.drain)

    def make_hub(self,parent):
        main=ctk.CTkScrollableFrame(parent,fg_color=BG);main.pack(fill='both',expand=True)
        self.label(main,'Dreamer. Всё в одном.',28,'white',anchor='w',pady=(8,4))
        self.label(main,'Прошивка, профиль Cura и сеть — в одном переносном приложении.',13,MUTED,anchor='w',pady=(0,10))
        card=self.card(main)
        self.label(card,'01 / MARLIN С РУССКИМ И WI-FI',17,'white',anchor='w',pady=(14,6))
        self.label(card,'Готовая сборка: меню сети на дисплее, Cura → SD, CRC32, Linear Advance K=0.\nСопла до 270 °C; окно ожидания ±5 °C; ось Z удерживается при простое.\nСетевой тест выполнен без движений и нагрева. Печать детали после обновления ещё не проверена.',12,MUTED,anchor='w',pady=(0,10))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=18,pady=(0,15))
        self.button(row,'Установить Marlin',lambda:self.install_bundled('marlin.bin','Marlin + Cura Wi-Fi'),ACCENT,width=195).pack(side='left',padx=(0,10))
        self.button(row,'Вернуть штатную RU 270',lambda:self.install_bundled('rollback-ru.bin','Штатная V2.15 RU 270'), '#253750',width=210).pack(side='left')
        card=self.card(main)
        self.label(card,'02 / CURA И ПРОФИЛИ',17,'white',anchor='w',pady=(14,6))
        self.label(card,'230 × 150 × 140 мм · T0 справа, T1 слева · оба экструдера в профиле.\nПо умолчанию печатает только левый: ABS 220 °C, стол 105 °C.\nВ комплекте: ABS LEFT Tuned, FlashPrint Standard, проект куба и варианты прошивки.\nАвтоустановка профиля рассчитана на Cura 5.13; перед ней закрой Cura.',12,MUTED,anchor='w',pady=(0,10))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=18,pady=(0,15))
        self.button(row,'Установить профиль Cura',self.configure_cura,ACCENT,width=210).pack(side='left',padx=(0,10))
        self.button(row,'Экспортировать весь комплект',self.export_all,'#253750',width=235).pack(side='left')
        self.button(row,'Открыть Cura',lambda:self.guarded(suite.launch_cura),'#253750',width=140).pack(side='left',padx=10)
        card=self.card(main)
        self.label(card,'03 / WI-FI И ИНСТРУКЦИЯ',17,'white',anchor='w',pady=(14,6))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=18,pady=4)
        ctk.CTkLabel(row,text='IP принтера',text_color=MUTED).pack(side='left',padx=(0,10))
        self.ip=ctk.CTkEntry(row,width=165);self.ip.insert(0,'192.168.88.222');self.ip.pack(side='left');self.controls.append(self.ip)
        try:self.ip.delete(0,'end');self.ip.insert(0,json.loads((DATA/'wifi.json').read_text(encoding='utf-8'))['host'])
        except (OSError,ValueError,KeyError):
            if not self.ip.get():self.ip.insert(0,'192.168.88.222')
        self.label(card,'Сначала подключи принтер к сети в его меню Wi-Fi. Введи показанный IP.\nМост работает в фоне; в Cura используется кнопка Print over network.\nОставь FAT32 SD-карту в принтере и закрой FlashPrint. Передача — около 6 КиБ/с.',12,MUTED,anchor='w',pady=(5,8))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=18,pady=(0,8))
        self.button(row,'Запустить мост',self.start_wifi,ACCENT,width=155).pack(side='left',padx=(0,8))
        self.button(row,'Проверить Wi-Fi',self.check_wifi,'#253750',width=160).pack(side='left',padx=(0,8))
        self.button(row,'Остановить мост',lambda:self.task(suite.stop_relay,'Мост остановлен'),'#253750',width=155).pack(side='left')
        self.button(card,'Открыть полную инструкцию',lambda:self.guarded(suite.guide),'#253750',width=260).pack(anchor='w',padx=18,pady=(0,16))

    def install_bundled(self,name,title):
        def run():
            payload=suite.checked(name)
            self.cancel_wait.clear()
            def work():
                log=[]
                def emit(text):log.append(str(text));self.events.put(('log',text))
                try:bootloader.install(payload,emit,lambda n:self.events.put(('progress',n)),self.cancel_wait)
                finally:
                    folder=DATA/'logs';folder.mkdir(parents=True,exist_ok=True)
                    import time
                    (folder/('bootloader-'+time.strftime('%Y%m%d-%H%M%S')+'.txt')).write_text('\n'.join(log),encoding='utf-8')
                return 'Установлено: '+title+'. Дождись главного меню. Затем проверь USB и Wi-Fi.'
            if messagebox.askokcancel('Установка '+title,'Будет заменена прошивка приложения Dreamer. Заверши печать и выключи нагрев.\n\nMarlin устанавливается готовой сборкой; настройки штатного сборщика к нему не применяются.\n\nПосле OK начнётся ожидание 3 минуты. Выключи принтер на 5 секунд и включи, оставив USB подключённым. Во время записи питание не отключай. Загрузчик v1.4 не заменяется.'):
                self.task(work,'Передача подтверждена')
        self.guarded(run)

    def configure_cura(self):
        if messagebox.askokcancel('Установить профиль Cura 5.13?','Закрой Cura. Будут установлены описание Dreamer с двумя соплами, профиль ABS LEFT 220/105 и локальный сетевой адрес. Правое сопло T0 останется отключено.\n\nСуществующие заменяемые файлы сохранятся в backups; настройки аккаунта и других принтеров не удаляются.'):
            self.task(suite.install_cura,'Cura настроена')
    def export_all(self):
        folder=filedialog.askdirectory(title='Куда сохранить прошивки, профили и инструкцию?')
        if folder:self.task(lambda:str(suite.export_bundle(folder)),'Комплект экспортирован')
    def start_wifi(self):
        def run():
            host=suite.validate_ip(self.ip.get());self.task(lambda:suite.start_relay(host),'Мост запущен')
        self.guarded(run)
    def check_wifi(self):
        def run():
            info=suite.relay_info();r=suite.relay_status(info['host'])
            return 'Принтер отвечает: '+r['name']+'\n'+r['platform']
        self.task(run,'Wi-Fi проверен')

    def label(self,parent,text,size,color,anchor='center',pady=0):
        w=ctk.CTkLabel(parent,text=text,font=('Segoe UI',size),text_color=color,anchor=anchor,justify='left')
        w.pack(fill='x',padx=18,pady=pady); return w
    def card(self,parent):
        c=ctk.CTkFrame(parent,fg_color=CARD,corner_radius=14); c.pack(fill='x',pady=6); return c
    def check(self,parent,text,var,sub):
        c=ctk.CTkCheckBox(parent,text=text,variable=var,font=('Segoe UI',17),fg_color=ACCENT)
        c.pack(anchor='w',padx=20,pady=(18,3)); self.controls.append(c)
        self.label(parent,sub,12,MUTED,anchor='w',pady=(0,4))
    def button(self,parent,text,command,color,width=145):
        b=ctk.CTkButton(parent,text=text,command=command,fg_color=color,height=39,width=width,font=('Segoe UI',13),corner_radius=8)
        self.controls.append(b); return b
    def options(self):
        try: values={k:int(e.get()) for k,e in self.entries.items()}
        except ValueError: raise ValueError('Температуры должны быть целыми числами')
        try: advance=float(self.advance_entry.get().replace(',','.'))
        except ValueError: raise ValueError('Коэффициент A должен быть числом')
        o=Options(russian=self.russian.get(),parallel=self.parallel.get(),print_timer=self.print_timer.get(),native_advance=self.native_advance.get(),native_advance_a=advance,**values); o.validate(); return o
    def log(self,text):
        self.logbox.configure(state='normal'); self.logbox.insert('end',str(text)+'\n'); self.logbox.see('end'); self.logbox.configure(state='disabled')
    def task(self,fn,success):
        if self.busy: return
        self.busy=True; self.bar.set(0);self.cancel_wait.clear()
        for c in self.controls: c.configure(state='disabled')
        self.status.configure(text='●  Выполняется…',text_color=ACCENT)
        def worker():
            try: result=fn(); self.events.put(('done',(success,result)))
            except Exception as e: self.events.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def drain(self):
        while not self.events.empty():
            kind,value=self.events.get()
            if kind=='log': self.log(value)
            elif kind=='progress': self.bar.set(value)
            else:
                self.busy=False
                for c in self.controls: c.configure(state='normal')
                if kind=='error':
                    self.status.configure(text='●  Операция остановлена',text_color='#ff947f'); self.log(value); messagebox.showerror('Операция остановлена',value)
                else:
                    text,result=value; self.status.configure(text='●  '+text,text_color=GREEN)
                    if result: self.log(result)
        self.after(100,self.drain)
    def guarded(self,fn):
        try: fn()
        except Exception as e: messagebox.showerror('Проверь настройки',str(e))
    def export(self): self.guarded(self._export)
    def _export(self):
        o=self.options(); path=filedialog.asksaveasfilename(defaultextension='.bin',initialfile='dreamer_custom.bin',filetypes=[('Прошивка Dreamer','*.bin')])
        if not path:return
        def run():
            payload,manifest=build(o); p=Path(path); p.write_bytes(payload); p.with_suffix('.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
            return 'Сохранено: '+str(p)+'\nSHA-256: '+manifest['sha256']
        self.task(run,'Сборка сохранена')
    def usb(self,payload=None):
        if payload is not None:
            log=[]
            def emit(text):log.append(str(text));self.events.put(('log',text))
            try:
                bootloader.install(payload,emit,lambda n:self.events.put(('progress',n)),self.cancel_wait)
                return 'Файл принят загрузчиком. Дождись установки и главного меню.'
            finally:
                folder=DATA/'logs';folder.mkdir(parents=True,exist_ok=True)
                import time
                (folder/('native-bootloader-'+time.strftime('%Y%m%d-%H%M%S')+'.txt')).write_text('\n'.join(log),encoding='utf-8')
        p=Printer(log=lambda text:self.events.put(('log',text)),progress=lambda val:self.events.put(('progress',val)))
        try:
            with p:
                if payload is None:
                    r=p.inspect(); return r['temperatures'].strip()+'\n'+r['status'].strip()
                p.upload(payload)
                return 'Передача завершена. Теперь вручную перезапусти принтер. Дождись завершения обновления.'
        finally:
            try: self.events.put(('log','Журнал: '+str(p.save_log(DATA/'logs'))))
            except Exception: pass
    def probe(self): self.task(suite.probe_usb,'USB проверен')
    def memory(self):
        # Capability test only: never pretends a vendor-specific interface is a mounted disk.
        def run():
            p=Printer(log=lambda text:self.events.put(('log',text)))
            try:
                with p:
                    return p.storage_capabilities()['message']
            finally:
                try:p.save_log(DATA/'logs')
                except Exception:pass
        self.task(run,'Проверка памяти завершена')
    def install(self): self.guarded(self._install)
    def _install(self):
        o=self.options()
        summary=f'T0: {o.t0_min}…{o.t0_max} °C\nT1: {o.t1_min}…{o.t1_max} °C\nСтол: {o.bed_min}…{o.bed_max} °C\nРусский: {"да" if o.russian else "нет"}\nОдновременный нагрев: {"да" if o.parallel else "нет"}\nТаймер с первой экструзии: {"да" if o.print_timer else "нет"}'
        if o.native_advance: summary+=f'\nЭКСПЕРИМЕНТ: штатная компенсация A={o.native_advance_a:g}, B=0.\nНа оборудовании не проверена; это не Marlin Linear Advance.'
        if not messagebox.askokcancel('Установить выбранную конфигурацию?',summary+'\n\nБудет заменена прошивка принтера. Заверши печать и выключи нагрев. После OK выключи принтер на 5 секунд и включи с подключённым USB: программа ждёт загрузчик 3 минуты. Во время передачи питание не отключай. Новые настройки требуют проверки на принтере.'): return
        def run():
            payload,manifest=build(o); folder=DATA/'builds'/manifest['sha256'][:16]; folder.mkdir(parents=True,exist_ok=True)
            (folder/'dreamer.bin').write_bytes(payload); (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
            self.events.put(('log','Сборка: '+str(folder))); return self.usb(payload)
        self.task(run,'Обновление активировано — перезапусти принтер')
    def rollback(self):
        if messagebox.askokcancel('Вернуть оригинальную прошивку?', 'Будет установлена оригинальная V2.15: без русского перевода и с заводскими ограничениями температуры. Заверши печать, выключи нагрев. После OK выключи принтер на 5 секунд и включи с подключённым USB: программа ждёт загрузчик 3 минуты. Во время записи питание не отключай.'):
            self.task(lambda:self.usb(original()),'Оригинал передан — перезапусти принтер')
    def save_profile(self): self.guarded(self._save_profile)
    def _save_profile(self):
        o=self.options(); path=filedialog.asksaveasfilename(defaultextension='.json',initialfile='dreamer_profile.json')
        if path: Path(path).write_text(json.dumps(asdict(o),ensure_ascii=False,indent=2),encoding='utf-8'); self.log('Профиль сохранён: '+path)
    def load_profile(self): self.guarded(self._load_profile)
    def _load_profile(self):
        path=filedialog.askopenfilename(filetypes=[('Профиль','*.json')])
        if not path:return
        o=Options(**json.loads(Path(path).read_text(encoding='utf-8'))); o.validate()
        self.russian.set(o.russian); self.parallel.set(o.parallel); self.print_timer.set(o.print_timer); self.native_advance.set(o.native_advance)
        self.advance_entry.delete(0,'end');self.advance_entry.insert(0,str(o.native_advance_a))
        for k,e in self.entries.items(): e.delete(0,'end'); e.insert(0,str(getattr(o,k)))
        self.log('Профиль загружен: '+path)
    def gcode(self): self.guarded(self._gcode)
    def _gcode(self):
        o=self.options(); dialog=ctk.CTkToplevel(self); dialog.title('Одновременный старт нагрева'); dialog.geometry('610x490'); dialog.transient(self); dialog.grab_set()
        self.label(dialog,'Температуры для стартового G-code',20,'white',pady=18)
        fields={}
        for name,title,default in [('t0','Сопло T0',min(o.t0_max,max(o.t0_min,210))),('t1','Сопло T1',0),('bed','Стол',min(o.bed_max,max(o.bed_min,60)))]:
            row=ctk.CTkFrame(dialog,fg_color='transparent'); row.pack(fill='x',padx=25,pady=6)
            ctk.CTkLabel(row,text=title,width=170,anchor='w').pack(side='left')
            e=ctk.CTkEntry(row); e.insert(0,str(default)); e.pack(side='left'); fields[name]=e
        self.label(dialog,'Стол и нужные сопла получают уставки до команды ожидания.\nВставь блок до первого ожидания в стартовом коде слайсера.\nДля T1 = 0 второе сопло будет выключено.\nИспользуются штатные ожидания Dreamer M7 / M6.',13,MUTED,pady=16)
        def save():
            try:
                code=start_gcode(o,**{k:int(e.get()) for k,e in fields.items()})
                path=filedialog.asksaveasfilename(parent=dialog,defaultextension='.gcode',initialfile='dreamer_parallel_start.gcode')
                if path: Path(path).write_text(code,encoding='ascii'); self.log('Стартовый код: '+path); dialog.destroy()
            except Exception as e: messagebox.showerror('Проверь температуры',str(e),parent=dialog)
        ctk.CTkButton(dialog,text='Сохранить G-code',command=save,height=42).pack(pady=12)
    def close(self):
        if self.busy: messagebox.showinfo('Дождись завершения','Сейчас выполняется операция. Не отключай USB во время передачи.'); return
        self.destroy()

if __name__=='__main__':
    if '--start-wifi' in sys.argv:
        try:suite.start_relay(suite.saved_host())
        except Exception as error:messagebox.showerror('Wi-Fi-мост',str(error));sys.exit(1)
    elif '--wifi-relay' in sys.argv:
        from dreamer_cura_bridge import serve
        host=suite.validate_ip(sys.argv[sys.argv.index('--host')+1]) if '--host' in sys.argv else suite.saved_host()
        serve(host)
    elif '--self-test' in sys.argv:
        import libusb_package
        try:
            payload,manifest=build(Options())
            assert len(original())==727444
            assert libusb_package.get_library_path()
            suite.verify()
            result=dict(ok=True,sha256=manifest['sha256'],size=len(payload),usb_library=str(libusb_package.get_library_path()),options=manifest['options'])
        except Exception as e:
            result=dict(ok=False,error=repr(e))
        index=sys.argv.index('--self-test')
        path=Path(sys.argv[index+1])
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        sys.exit(0 if result['ok'] else 1)
    elif '--ui-smoke' in sys.argv:
        target=Path(sys.argv[sys.argv.index('--ui-smoke')+1]);app=App();app.update()
        result={'ok':True,'title':app.title(),'tabs':list(app.tabs._tab_dict),'controls':len(app.controls)}
        target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');app.destroy()
    else:
        App().mainloop()
