param([string]$Python='python', [string]$Destination=(Join-Path $PSScriptRoot 'dist'))
$ErrorActionPreference='Stop'
& $Python -m PyInstaller --noconfirm --onefile --windowed --name DreamerStudio --distpath $Destination --workpath (Join-Path $PSScriptRoot 'build') --specpath $PSScriptRoot --paths $PSScriptRoot --add-data "$PSScriptRoot/assets;assets" --collect-all customtkinter --collect-all libusb_package --collect-all keystone (Join-Path $PSScriptRoot 'app.py')
if ($LASTEXITCODE -ne 0) { throw 'Dreamer Studio build failed' }
