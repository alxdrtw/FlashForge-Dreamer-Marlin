"""USB transport; no movement, heating, driver changes or reset commands."""
import hashlib, json, re, time
from pathlib import Path
import usb.core, usb.util, libusb_package

class Printer:
    def __init__(self, log=lambda text: None, progress=lambda value: None, device=None):
        self.log, self.progress, self.device = log, progress, device
        self.controlled=False; self.events=[]

    def __enter__(self):
        try:
            if self.device is None:
                devices=[d for d in libusb_package.find(find_all=True) if d.idVendor in (0x2b71,0x0315) and d.idProduct==1]
                if len(devices)!=1: raise RuntimeError('Подключите ровно один Dreamer по USB. Закройте FlashPrint и другие загрузчики.')
                self.device=devices[0]
                usb.util.claim_interface(self.device,0)
            if 'Control Success' not in self.command('M601 S0'): raise RuntimeError('Принтер не предоставил управление')
            self.controlled=True
            identity=self.command('M115')
            if not re.search(r'^Machine Type: Flashforge Dreamer\r?$',identity,re.M) or 'Tool Count: 2' not in identity or 'Firmware: V2.15 20200917' not in identity:
                raise RuntimeError('Нужен двухсопельный Flashforge Dreamer с V2.15 20200917. Другие модели и версии не поддерживаются.')
            self.identity=identity
            return self
        except Exception:
            self.__exit__(None,None,None)
            raise

    def command(self, cmd, timeout=2500):
        self.log('→ '+cmd)
        packet=('~'+cmd+'\r\n').encode('ascii')
        if self.device.write(1,packet,timeout=1500)!=len(packet): raise RuntimeError('Неполная передача команды USB')
        chunks=[]
        for _ in range(32):
            try: chunks.append(bytes(self.device.read(0x81,4096,timeout=timeout)))
            except usb.core.USBTimeoutError: break
            if re.search(rb'(?:^|\n)ok\r?\n',b''.join(chunks)): break
        reply=b''.join(chunks).decode('utf-8',errors='replace')
        self.log(reply.strip()); self.events.append(dict(command=cmd,reply=reply))
        if not re.search(r'(?:^|\n)ok\r?\n',reply): raise RuntimeError('Принтер не подтвердил команду: '+cmd)
        if re.search(r'failed|error|out of space|busying|unknown command',reply,re.I): raise RuntimeError('Ошибка принтера: '+reply.strip())
        return reply

    def inspect(self):
        return dict(identity=self.identity, temperatures=self.command('M105'), status=self.command('M119'))

    def storage_capabilities(self):
        status=self.command('M119')
        if not re.search(r'^MachineStatus:\s*READY\s*$',status,re.M):
            raise RuntimeError('Проверять файловый интерфейс можно только на свободном принтере.')
        interfaces=[dict(number=i.bInterfaceNumber,alternate=i.bAlternateSetting,usb_class=i.bInterfaceClass) for c in self.device for i in c]
        mass_storage=any(i['usb_class']==8 for i in interfaces)
        replies={cmd:self.command(cmd) for cmd in ['M20','M661']}
        message=('Обнаружен интерфейс USB Mass Storage. Диски проверяются средствами Windows.' if mass_storage else
                 'USB-диск недоступен: прошивка предоставляет фирменный интерфейс, а не Mass Storage. '
                 'Кнопка выполнила только проверку. Карта не смонтирована; файлы не изменены.')
        self.log(message)
        return dict(mass_storage=mass_storage,interfaces=interfaces,replies=replies,message=message)

    def upload(self, payload):
        temps=self.command('M105')
        targets=re.findall(r'/\s*(-?\d+(?:\.\d+)?)',temps)
        if len(targets)!=3 or any(float(v)!=0 for v in targets): raise RuntimeError('Перед обновлением выключите все три нагревателя.')
        status=self.command('M119')
        if not re.search(r'^MachineStatus:\s*READY\s*$',status,re.M): raise RuntimeError('Обновление разрешено только в состоянии READY. Остановите печать и дождитесь готовности.')
        if not re.search(r'^MoveMode:\s*READY\s*$',status,re.M): raise RuntimeError('Завершите движение принтера перед обновлением.')
        reply=self.command(f'M28 {len(payload)} 0:/sys/dreamer.bin')
        if 'Writing to file:' not in reply or f'Length: {len(payload)}' not in reply: raise RuntimeError('Создание файла прошивки не подтверждено')
        for off in range(0,len(payload),16384):
            block=payload[off:off+16384]
            if self.device.write(3,block,timeout=15000)!=len(block): raise RuntimeError('Неполная передача. Обновление не активировано.')
            self.progress((off+len(block))/len(payload)*0.9)
        if 'Done saving file.' not in self.command('M29 '+hashlib.md5(payload).hexdigest(),8000): raise RuntimeError('Контрольная сумма файла не подтверждена. Обновление не активировано.')
        self.progress(.95)
        if 'succeed' not in self.command('M600',5000).lower(): raise RuntimeError('Принтер не подтвердил активацию обновления')
        self.progress(1)
        self.log('Файл принят и обновление активировано. Перезапустите принтер вручную и дождитесь завершения установки.')

    def __exit__(self,*args):
        if self.controlled:
            try: self.command('M602')
            except Exception as e: self.log('Освобождение USB: '+str(e))
            self.controlled=False
        if self.device is not None:
            try: usb.util.dispose_resources(self.device)
            except Exception: pass

    def save_log(self, directory):
        directory=Path(directory); directory.mkdir(parents=True,exist_ok=True)
        path=directory/('usb-'+time.strftime('%Y%m%d-%H%M%S')+'.json')
        path.write_text(json.dumps(self.events,ensure_ascii=False,indent=2),encoding='utf-8')
        return path
